package ru.doublebyte.telegramWeatherBot.enums;

/**
 * Message parsing mode
 */
public enum ParseMode {

    Markdown

}
