package ru.doublebyte.telegramWeatherBot.enums;

/**
 * Weather result units
 */
public enum WeatherUnits {
    metric,
    imperial,
    standard
}
